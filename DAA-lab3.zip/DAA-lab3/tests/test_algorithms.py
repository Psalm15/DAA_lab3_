import unittest

from algorithms.activity_selection import activity_selection
from algorithms.fractional_knapsack import fractional_knapsack
from algorithms.huffman_coding import build_huffman_tree, generate_codes, huffman_encode


class TestFractionalKnapsack(unittest.TestCase):
    def setUp(self):
        self.items = [
            {"name": "Gold", "weight": 10, "value": 60},
            {"name": "Silver", "weight": 20, "value": 100},
            {"name": "Bronze", "weight": 30, "value": 120},
        ]

    def test_classic_example(self):
        value, weight, selected = fractional_knapsack(self.items, 50)
        self.assertAlmostEqual(value, 240.0)
        self.assertAlmostEqual(weight, 50.0)
        self.assertEqual([i["name"] for i in selected], ["Gold", "Silver", "Bronze"])
        self.assertAlmostEqual(selected[-1]["fraction"], 2 / 3)

    def test_zero_capacity(self):
        value, weight, selected = fractional_knapsack(self.items, 0)
        self.assertEqual((value, weight, selected), (0.0, 0.0, []))

    def test_capacity_larger_than_total_weight(self):
        value, weight, _ = fractional_knapsack(self.items, 1000)
        self.assertAlmostEqual(value, 280.0)
        self.assertAlmostEqual(weight, 60.0)

    def test_invalid_input(self):
        with self.assertRaises(ValueError):
            fractional_knapsack(self.items, -1)
        with self.assertRaises(ValueError):
            fractional_knapsack([{"name": "x", "weight": 0, "value": 5}], 10)


class TestActivitySelection(unittest.TestCase):
    def test_classic_example(self):
        activities = [
            {"name": "A1", "start": 1, "finish": 4},
            {"name": "A2", "start": 3, "finish": 5},
            {"name": "A3", "start": 0, "finish": 6},
            {"name": "A4", "start": 5, "finish": 7},
            {"name": "A5", "start": 3, "finish": 9},
            {"name": "A6", "start": 5, "finish": 9},
            {"name": "A7", "start": 6, "finish": 10},
            {"name": "A8", "start": 8, "finish": 11},
        ]
        selected = activity_selection(activities)
        self.assertEqual([a["name"] for a in selected], ["A1", "A4", "A8"])

    def test_no_overlaps_in_result(self):
        activities = [{"name": f"A{i}", "start": i, "finish": i + 3} for i in range(20)]
        selected = activity_selection(activities)
        for a, b in zip(selected, selected[1:]):
            self.assertLessEqual(a["finish"], b["start"])

    def test_empty_and_invalid(self):
        self.assertEqual(activity_selection([]), [])
        with self.assertRaises(ValueError):
            activity_selection([{"name": "bad", "start": 5, "finish": 2}])


class TestHuffmanCoding(unittest.TestCase):
    def test_abracadabra(self):
        result = huffman_encode("abracadabra")
        self.assertEqual(result["original_bits"], 88)
        self.assertEqual(result["encoded_bits"], 23)
        self.assertEqual(result["frequencies"]["a"], 5)

    def test_prefix_free_and_decodable(self):
        text = "huffman coding is a greedy algorithm"
        result = huffman_encode(text)
        codes = result["codes"]

        # No code may be a prefix of another.
        for c1 in codes.values():
            for c2 in codes.values():
                if c1 != c2:
                    self.assertFalse(c2.startswith(c1))

        # Decoding the output must give back the original text.
        reverse = {code: char for char, code in codes.items()}
        decoded, buffer = [], ""
        for bit in result["encoded"]:
            buffer += bit
            if buffer in reverse:
                decoded.append(reverse[buffer])
                buffer = ""
        self.assertEqual("".join(decoded), text)

    def test_single_character_text(self):
        codes = generate_codes(build_huffman_tree("aaaa"))
        self.assertEqual(codes, {"a": "0"})

    def test_empty_text(self):
        with self.assertRaises(ValueError):
            huffman_encode("")


if __name__ == "__main__":
    unittest.main()
