"""Generate time and memory graphs from results/benchmark_results.csv.

Run from the project root (after run_benchmarks.py):
    python plot_performance.py          # save graphs only
    python plot_performance.py --show   # also open the plot windows
"""

import os
import sys

import matplotlib.pyplot as plt
import pandas as pd

SHOW_PLOTS = "--show" in sys.argv

# Create the graphs folder if it does not exist
os.makedirs("graphs", exist_ok=True)

# Load benchmark results
if not os.path.exists("results/benchmark_results.csv"):
    sys.exit("results/benchmark_results.csv not found. Run run_benchmarks.py first.")

df = pd.read_csv("results/benchmark_results.csv")


# ==========================================
# Graph 1: Execution Time Comparison
# ==========================================

plt.figure(figsize=(10, 6))

for algorithm in df["Algorithm"].unique():
    subset = df[df["Algorithm"] == algorithm]

    plt.plot(
        subset["Input Size"],
        subset["Execution Time (seconds)"],
        marker="o",
        label=algorithm
    )

plt.xlabel("Input Size")
plt.ylabel("Average Execution Time (seconds)")
plt.title("Greedy Algorithms: Execution Time Comparison")
plt.legend()
plt.grid(True)

plt.savefig(
    "graphs/performance_time.png",
    dpi=150,
    bbox_inches="tight"
)

if SHOW_PLOTS:
    plt.show()
plt.close()


# ==========================================
# Graph 2: Memory Usage Comparison
# ==========================================

plt.figure(figsize=(10, 6))

for algorithm in df["Algorithm"].unique():
    subset = df[df["Algorithm"] == algorithm]

    plt.plot(
        subset["Input Size"],
        subset["Peak Traced Memory (KiB)"],
        marker="o",
        label=algorithm
    )

plt.xlabel("Input Size")
plt.ylabel("Peak Traced Memory (KiB)")
plt.title("Greedy Algorithms: Memory Usage Comparison")
plt.legend()
plt.grid(True)

plt.savefig(
    "graphs/performance_memory.png",
    dpi=150,
    bbox_inches="tight"
)

if SHOW_PLOTS:
    plt.show()
plt.close()

print("Performance graphs saved successfully!")
print("Check the graphs folder.")