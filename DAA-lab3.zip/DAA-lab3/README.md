# DAA Lab 3: Greedy Algorithms

Python implementations of three classic greedy algorithms, with benchmarking
of execution time and memory usage, plus a comparison against theoretical complexity.

| Algorithm | Idea | Time | Auxiliary space |
|---|---|---|---|
| Fractional Knapsack | Take items in decreasing value/weight ratio | O(n log n) | O(n) |
| Activity Selection | Take activities in increasing finish time | O(n log n) | O(n) |
| Huffman Coding | Repeatedly merge the two least frequent nodes (min-heap) | O(L + k log k) | O(k + L) |

For Huffman coding, *L* is the text length and *k* is the number of distinct characters.

## Project structure

```
DAA-lab3/
├── algorithms/
│   ├── fractional_knapsack.py
│   ├── activity_selection.py
│   └── huffman_coding.py
├── benchmarking/
│   └── benchmark.py              # time + memory measurement helper
├── tests/
│   └── test_algorithms.py        # unit tests
├── results/
│   ├── benchmark_results.csv
│   └── complexity_comparison.csv
├── graphs/
│   ├── performance_time.png
│   └── performance_memory.png
├── main.py                       # demo of all three algorithms
├── run_benchmarks.py             # runs benchmarks, writes results/benchmark_results.csv
├── plot_performance.py           # creates graphs from the CSV
├── create_complexity_table.py    # writes results/complexity_comparison.csv
└── requirements.txt
```

## Setup

Requires Python 3.9+.

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Usage

Run everything from the project root.

```bash
python main.py                  # demo of the three algorithms
python run_benchmarks.py        # benchmark (input sizes 100, 500, 1000, 5000)
python plot_performance.py      # save graphs to graphs/  (add --show to open windows)
python create_complexity_table.py
python -m unittest discover     # run the tests
```

## Results

![Execution time](graphs/performance_time.png)
![Memory usage](graphs/performance_memory.png)

Memory is the peak traced by Python's `tracemalloc` (in KiB), so it reflects
Python object allocations only, not total process memory.

## Notes

- Fractional Knapsack and Activity Selection are dominated by sorting, so they
  scale as O(n log n).
- Huffman Coding builds a heap over the *k* distinct characters, so with a
  fixed alphabet (26 letters here) its cost grows roughly linearly with text length.
